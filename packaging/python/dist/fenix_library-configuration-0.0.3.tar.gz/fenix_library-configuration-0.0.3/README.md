
# Configuration - Fenix Library - RebornOS Team

*Documentation by @shivanandvp (shivanandvp@rebornos.org)*  

*Please refer to [`LICENSE`](./LICENSE) for license information.*

## Overview

The **configuration** package consists of the tools required to read and write `JSON` configuration files.

**Warning**: This package is still in the Alpha stage. It is not ready for production projects. Please do not use for any critical software

## [PLEASE CLICK HERE](https://rebornos-team.gitlab.io/fenix/libraries/configuration/index.html) for the full documentation